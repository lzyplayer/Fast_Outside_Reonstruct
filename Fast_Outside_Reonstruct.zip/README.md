# Fast_Outside_Reonstruct
